document.addEventListener('DOMContentLoaded', () => {
    loadPlants();
});

function loadPlants() {
    const plantList = JSON.parse(localStorage.getItem('plants')) || [];
    const result = document.getElementById('result');
    result.innerHTML = '';
    plantList.forEach((plant, index) => {
        const row = `<tr>
            <td>${plant.name}</td>
            <td>${plant.country}</td>
            <td>${plant.available}</td>
            <td>${plant.uses}</td>
            <td>
                <button class="btn btn-success" onclick="editPlant(${index})">EDIT</button>
                <button class="btn btn-danger" onclick="deletePlant(${index})">DELETE</button>
            </td>
        </tr>`;
        result.innerHTML += row;
    });
}

function addPlant(event) {
    event.preventDefault();
    const plantList = JSON.parse(localStorage.getItem('plants')) || [];
    const name = document.getElementById('plantname').value;
    const country = document.getElementById('countrySelect').value;
    const available = document.getElementById('count').value;
    const uses = document.getElementById('uses').value;
    const plant = { name, country, available, uses };

    plantList.push(plant);
    localStorage.setItem('plants', JSON.stringify(plantList));
    loadPlants();
    document.getElementById('formId').reset();
}

function editPlant(index) {
    const plantList = JSON.parse(localStorage.getItem('plants'));
    const plant = plantList[index];
    document.getElementById('plantname').value = plant.name;
    document.getElementById('countrySelect').value = plant.country;
    document.getElementById('count').value = plant.available;
    document.getElementById('uses').value = plant.uses;
    deletePlant(index);
}

function deletePlant(index) {
    const plantList = JSON.parse(localStorage.getItem('plants'));
    plantList.splice(index, 1);
    localStorage.setItem('plants', JSON.stringify(plantList));
    loadPlants();
}

function resetValues() {
    document.getElementById('formId').reset();
}
